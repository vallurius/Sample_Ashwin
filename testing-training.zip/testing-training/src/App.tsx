import React from 'react';
import './App.css';
import {Main} from "./Main";

function App() {
  return (
    <Main msg={'sample'}/>
  );
}

export default App;
