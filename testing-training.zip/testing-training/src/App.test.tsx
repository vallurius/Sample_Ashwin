import React from 'react';
import {configure, mount, shallow} from "enzyme";
import Adapter from 'enzyme-adapter-react-16';
import {Main} from './Main';
import App from './App';

configure({adapter: new Adapter()})

describe('App Test Suite', () => {

  test('render the app component', () => {
    const component = shallow(<App />);
    expect(component.getElements()).toMatchSnapshot();
  });

  test('checks the props passed to component', () => {
    const component = mount(<Main msg='sample'/>);
    console.log(component);
    expect(component.find('div').text()).toEqual('sample');
  });
})

