import React from "react";

export const Main = (msg: any) => {
    return <div>{msg.msg}</div>;
}

